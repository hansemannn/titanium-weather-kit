//
//  TiWeatherkit.h
//  titanium-weather-kit
//
//  Created by Your Name
//  Copyright (c) 2022 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiWeatherkit.
FOUNDATION_EXPORT double TiWeatherkitVersionNumber;

//! Project version string for TiWeatherkit.
FOUNDATION_EXPORT const unsigned char TiWeatherkitVersionString[];

#import "TiWeatherkitModuleAssets.h"
